package finalExam;

public class ParameterInvalidException extends Exception {
    public ParameterInvalidException (String s) {

    }
}
