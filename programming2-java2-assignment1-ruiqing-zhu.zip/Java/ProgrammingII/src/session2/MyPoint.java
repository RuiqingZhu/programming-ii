package session2;

public class MyPoint {
    private double x;
    private double y;

    private double getX()
    {
        return x;
    }

    private double getY()
    {
        return y;
    }

    public MyPoint()
    {
        x = 0;
        y = 0;
    }

    public MyPoint(double newX, double newY)
    {
        x = newX;
        y = newY;
    }

    public double distance(MyPoint otherPoint)
    {
        return distance(otherPoint.getX(), otherPoint.getY());
    }

    public double distance(double specifiedX, double specifiedY)
    {
        return Math.sqrt((Math.pow(( - specifiedX), 2) + Math.pow((y - specifiedY), 2)));
    }

}
