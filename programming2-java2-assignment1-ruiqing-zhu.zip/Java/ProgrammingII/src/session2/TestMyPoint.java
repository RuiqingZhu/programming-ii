package session2;

public class TestMyPoint {
    public static void main(String[] args)
    {
        System.out.println("The distance between (0,0) and (10,30.5) is " + new MyPoint().distance(new MyPoint(10, 30.5)));
    }
}
