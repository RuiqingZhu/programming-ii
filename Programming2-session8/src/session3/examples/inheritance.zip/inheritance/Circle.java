package session3.examples.inheritance;

public class Circle extends Shape {
//    private String color;
    private int radius;
}
